from starlette.staticfiles import StaticFiles as StaticFiles  # noqa
